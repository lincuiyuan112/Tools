//
//  UIView+frame.h
//  baisibudejie
//
//  Created by LCY on 16/7/3.
//  Copyright © 2016年 lincuiyuan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (frame)

@property CGFloat LCY_x;
@property CGFloat LCY_y;
@property CGFloat LCY_width;
@property CGFloat LCY_height;
@property CGFloat LCY_centerX;
@property CGFloat LCY_centerY;


@end
